# 韓國貓用品可攜回候選 100 筆整合版

- 產出日期：2026-06-27 14:31
- 構成：第二輪 50 筆 + 第三輪新增 50 筆
- 已排除：食品、零食、乾糧、濕食、肉泥、凍乾、拌料、含動物來源成分品項、貓草/貓薄荷/木天蓼/植物材料玩具、材質不明且疑似植物/動物來源候選。
- 第三輪由 3 個 Sub-Agent 平行搜尋，父代理再整併、去重與硬性過濾。
- 台灣來源多為搜尋/比價線索，不代表正式代理。

## 檔案

- `korea_cat_pet_supplies_100_bringback_safe_integrated.xlsx`：主檔，含 100 筆、Source Index、優先短名單、排除候選、方法限制。
- `korea_cat_pet_supplies_100_bringback_safe_integrated.csv`：100 筆扁平資料。
- `parent_verification_100_bringback_safe.txt`：父代理 QA 紀錄。
